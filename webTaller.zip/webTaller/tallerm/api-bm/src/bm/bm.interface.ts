export interface BmDto{
    readonly description: string;
    readonly isDone: boolean;
}