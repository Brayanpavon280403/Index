export class BmDto {
    readonly description: string;
    readonly isDone: boolean;
}